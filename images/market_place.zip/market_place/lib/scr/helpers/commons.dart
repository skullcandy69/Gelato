import 'package:flutter/material.dart';

const Color red = Colors.red;
const Color green = Colors.green;
const Color black = Colors.black;
const Color blue = Colors.blue;
const Color amber = Colors.amber;
const Color white = Colors.white;
const Color purple = Colors.purple;
const Color pink = Colors.pink;
const Color grey = Colors.grey;
