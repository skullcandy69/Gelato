import 'package:flutter/material.dart';
import 'package:market_place/scr/screens/login.dart';
import 'package:market_place/scr/widgets/carousel.dart';
import 'package:market_place/scr/widgets/categories.dart';
import 'package:market_place/scr/helpers/commons.dart';
import 'package:market_place/scr/widgets/popular_product.dart';
import 'package:sticky_headers/sticky_headers/widget.dart';
//import 'package:firebase_admob/firebase_admob.dart';
import 'package:flutter_native_admob/flutter_native_admob.dart';
//
//MobileAdTargetingInfo targetingInfo = MobileAdTargetingInfo(
//  keywords: <String>['chicken', 'food'],
//  contentUrl: 'https://www.zomato.com/ncr',
//  childDirected: false,
//  testDevices: <String>[], // Android emulators are considered test devices
//);
String appunitid='ca-app-pub-9800396717606741/7529455055';

//BannerAd createBannerAd() {
//  return BannerAd(
//    adUnitId: BannerAd.testAdUnitId,
//    size: AdSize.banner,
//    targetingInfo: targetingInfo,
//    listener: (MobileAdEvent event) {
//      print("BannerAd event $event");
//    },
//  );
//}




Future<Null> _handleRefresh() async {
  await new Future.delayed(new Duration(seconds: 2));
  return null;
}
//BannerAd _bannerAd = createBannerAd()..load();
class HomePage extends StatefulWidget {

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
//    _bannerAd = createBannerAd()..load()..show(
//        horizontalCenterOffset: 0, anchorOffset: 55
//    );

  }

  @override
  void dispose() {
//    _bannerAd?.dispose();
//    _bannerAd=null;

    super.dispose();
  }
  @override
  Widget build(BuildContext context) {

    const _adUnitID = "ca-app-pub-3940256099942544/8135179316";
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _handleRefresh,
        child: ListView(
          children: <Widget>[
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                IconButton(
                  icon: Icon(
                    Icons.location_on,
                    color: red,
                  ),
                  onPressed: () {},
                ),
                Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Text(
                    'Home - Block A kalkaji dou...',
                    style:
                    TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                  ),
                ),
                Stack(
                  children: <Widget>[
                    IconButton(
                        icon: Icon(
                          Icons.notifications_none,
                          color: black,
                        ),
                        onPressed: null),
                    Positioned(
                      top: 12,
                      right: 12,
                      child: Container(
                        height: 10,
                        width: 10,
                        decoration: BoxDecoration(
                            color: red,
                            borderRadius: BorderRadius.circular(20)),
                      ),
                    )
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 5,
            ),
            StickyHeader(
                header: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    decoration: BoxDecoration(color: white, boxShadow: [
                      BoxShadow(
                          color: grey, offset: Offset(1, 2), blurRadius: 10)
                    ]),
                    child: ListTile(
                      leading: Icon(
                        Icons.search,
                        color: red,
                      ),
                      trailing: Icon(
                        Icons.filter_list,
                        color: red,
                      ),
                      title: TextField(
                        decoration: InputDecoration(
                            hintText: 'Find food and restaurent',
                            border: InputBorder.none),
                      ),
                    ),
                  ),
                ),
                content: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 5,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Row(
                        children: <Widget>[
                          Text(
                            'Coupons',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 18,
                                color: grey),
                          ),
                        ],
                      ),
                    ),
                    Coupons(),
                    SizedBox(
                      height: 5,
                    ),

                  Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Row(
                        children: <Widget>[
                          Text(
                            'Categories',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 18,
                                color: grey),
                          ),
                        ],
                      ),
                    ),

                    Categories(),
                    SizedBox(
                      height: 5,
                    ),
                    NativeAdmobBannerView(
                      // Your ad unit id
                      adUnitID: _adUnitID,

                      // Styling native view with options
                      options: const BannerOptions(
                        backgroundColor: Colors.white,
                        indicatorColor: Colors.black,
                        ratingColor: Colors.yellow,
                        adLabelOptions: const TextOptions(
                          fontSize: 12,
                          color: Colors.white,
                          backgroundColor: Color(0xFFFFCC66),
                        ),
                        headlineTextOptions: const TextOptions(
                          fontSize: 16,
                          color: Colors.black,
                        ),
                        advertiserTextOptions: const TextOptions(
                          fontSize: 14,
                          color: Colors.black,
                        ),
                        bodyTextOptions: const TextOptions(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                        storeTextOptions: const TextOptions(
                          fontSize: 12,
                          color: Colors.black,
                        ),
                        priceTextOptions: const TextOptions(
                          fontSize: 12,
                          color: Colors.black,
                        ),
                        callToActionOptions: const TextOptions(
                          fontSize: 15,
                          color: Colors.white,
                          backgroundColor: Color(0xFF4CBE99),
                        ),
                      ),
                      showMedia: true,

                      // Content paddings
                      contentPadding: EdgeInsets.all(10),

                      onCreate: (controller) {
                        // controller.setOptions(BannerOptions()); // change view styling options
                      },
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Row(
                        children: <Widget>[
                          Text(
                            'Popular Food',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 18,
                                color: grey),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                        onTap:  () {
//                          _bannerAd?.dispose();
//                          _bannerAd = null;
                        },
                        child: Popular()),
                  ],
                ))
          ],
        ),
      ),
    );
  }
}
