
class Carousel{
  final String image;

  Carousel( this.image);

}