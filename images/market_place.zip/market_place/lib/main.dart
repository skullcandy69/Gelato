//import 'package:firebase_admob/firebase_admob.dart';
import 'package:flutter/material.dart';
import 'package:market_place/scr/screens/home.dart';
import 'package:market_place/scr/screens/login.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main()async{

  WidgetsFlutterBinding.ensureInitialized();
  //FirebaseAdMob.instance.initialize(appId: 'ca-app-pub-9800396717606741~3973353423');
  SharedPreferences prefs = await SharedPreferences.getInstance();
  var issignedin = prefs.getString('issignedin');
  print(issignedin);
  runApp(MaterialApp(home: issignedin == 'true' ?  Home():LoginScreen() ,theme: ThemeData(
    primarySwatch: Colors.red,
  ),));
//  runApp(MyApp());

}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: LoginScreen(),
    );
  }
}
